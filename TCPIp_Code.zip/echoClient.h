int isValid(char *msg);
int passMessage(const char *ipAddr);
int createSocket(const char *ipAddr);
int sendCommand();